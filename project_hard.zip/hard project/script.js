 const mailList = document.getElementById('mailList');
const mailContent = document.getElementById('mailContent');
const notification = document.getElementById('notification');
const composeMail = document.getElementById('composeMail');
const subjectInput = document.getElementById('subjectInput');
const phoneInput = document.getElementById('phoneInput');
const contentInput = document.getElementById('contentInput');
const sendMailBtn = document.getElementById('sendMailBtn');

const mails = [
    { subject: 'مرحبا!', content: 'كيف حالك اليوم؟' },
    { subject: 'تذكير', content: 'تذكر الاجتماع غدًا.' },
    { subject: 'عرض جديد', content: 'لقد أضفنا ميزات جديدة!' }
];

// عرض الرسائل في القائمة
function displayMails() {
    mailList.innerHTML = '';
    mails.forEach((mail, index) => {
        const li = document.createElement('li');
        li.textContent = mail.subject;
        li.onclick = () => showMail(index);
        mailList.appendChild(li);
    });
}

// عرض محتوى الرسالة
function showMail(index) {
    mailContent.textContent = mails[index].content;
    composeMail.style.display = 'none'; // إخفاء صندوق الرسالة الجديدة
    updateNotification();
}

// تحديث الإشعارات
function updateNotification() {
    notification.textContent = `${mails.length - mailList.children.length} رسالة جديدة`;
}

// إظهار صندوق كتابة رسالة جديدة
document.getElementById('newMailBtn').onclick = () => {
    composeMail.style.display = 'block'; // عرض صندوق كتابة الرسالة الجديدة
    mailContent.textContent = ''; // إخفاء محتوى الرسالة
};

// إرسال رسالة جديدة
sendMailBtn.onclick = () => {
    const newMail = {
        subject: subjectInput.value,
        phone: phoneInput.value,
        content: contentInput.value
    };
    if (newMail.subject && newMail.phone && newMail.content) {
        mails.push(newMail);
        subjectInput.value = '';
        phoneInput.value = '';
        contentInput.value = '';
        composeMail.style.display = 'none'; // إخفاء صندوق الرسالة الجديدة
        displayMails(); // تحديث قائمة الرسائل
        updateNotification(); // تحديث الإشعارات
    } else {
        alert('يرجى ملء جميع الحقول!');
    }
};

// عرض الرسائل الأولية
displayMails();
